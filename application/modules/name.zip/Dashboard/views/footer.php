<!--**********************************
    Content body end
***********************************-->

<!--**********************************
    Footer start
***********************************-->
<style>
    .home-footer[data-v-3db0d5d0] {

    width: 100vw;
    padding-bottom: env(safe-area-inset-bottom);
    position: fixed;
    bottom: 0;
    box-shadow: 0 0 0.55556rem rgb(0 0 0 / 5%);
    background: #2f0441;
    display: flex;
    align-items: center;
}
.home-footer>ul.nav[data-v-3db0d5d0] {
    flex: 1;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding:0px 9px;
    /*padding: 1.11111rem 2.22222rem;*/
}
ul {
    list-style: none;
}
.home-footer>ul.nav li[data-v-3db0d5d0] {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color: #fff;
}
.home-footer>ul.nav li .nav-icon-active[data-v-3db0d5d0] {
    /*display: none;*/
}

.home-footer>ul.nav li span[data-v-3db0d5d0] {
     font-size: 14px;
     margin-top: 0.34444rem;
}
.home-footer>ul.nav li.active[data-v-3db0d5d0] {
    color: var(--primary-color);
}
.home-footer>ul.nav li[data-v-3db0d5d0] {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

}
.home-footer>ul.nav li.active .nav-icon-active[data-v-3db0d5d0] {
    display: block;
}
.home-footer>ul.nav li.active .nav-icon[data-v-3db0d5d0] {
    /*display: none;*/
}
.home-footer>ul.nav li span[data-v-3db0d5d0] {
    font-size: 1.0rem;  font-size: 14px;      margin-top: 0.34444rem;
}
.home-footer>ul.nav li.active[data-v-3db0d5d0] {
    color: var(--primary-color);
}
.home-footer>ul.nav li[data-v-3db0d5d0] {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    color: #fff;
}
.home-footer>ul.nav li .nav-icon-active[data-v-3db0d5d0] {
    /*display: none;*/
}
.home-footer>ul.nav li .nav-icon[data-v-3db0d5d0] {
        display: block;
    margin: auto;
    max-width: 25px !important;
}
.home-footer>ul.nav li span[data-v-3db0d5d0] {
     font-size: 14px;
   margin-top: 0.34444rem;
}
.home-footer>ul.nav li span[data-v-3db0d5d0] {
      font-size: 14px;
      margin-top: 0.64444rem;
}
.home-footer>ul.nav li span[data-v-3db0d5d0] {
    font-size: 14px;
    margin-top: 0.34444rem;
}
.footer {
    display: none;
}
.footer .copyright {
    padding: 0px!important;
}



    @media (max-width: 767px){
      .footer {
    display: block !important;

}
    }


</style>

<?php $user_info = userinfo();?>
<script type="text/javascript" src="https://files.coinmarketcap.com/static/widget/coinMarquee.js"></script><div id="coinmarketcap-widget-marquee" coins="1,1027,825,1839,52,2010,5426,74,6636,3890,4943,1958,5805,5994" currency="USD" theme="light" transparent="false" show-symbol-logo="true"></div>

<div class="footer text-center">
    <strong>Copyright @2022. Ricaverse All rights reserved</span.
</div>

<!--**********************************
    Footer end
***********************************-->





<!--**********************************
   Support ticket button start
***********************************-->

<!--**********************************
   Support ticket button end
***********************************-->


</div>
<!--**********************************
Main wrapper end
***********************************-->

<!--**********************************
Scripts
***********************************-->
<!-- Required vendors -->
<script src="<?php echo base_url('againdashboard/');?>vendor/global/global.min.js"></script>
<script src="<?php echo base_url('againdashboard/');?>vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="<?php echo base_url('againdashboard/');?>vendor/chart.js/Chart.bundle.min.js"></script>

<!-- Chart piety plugin files -->
<script src="<?php echo base_url('againdashboard/');?>vendor/peity/jquery.peity.min.js"></script>

<!-- Apex Chart -->
<script src="<?php echo base_url('againdashboard/');?>vendor/apexchart/apexchart.js"></script>

<!-- Dashboard 1 -->
<script src="<?php echo base_url('againdashboard/');?>js/dashboard/dashboard-1.js"></script>

<script src="<?php echo base_url('againdashboard/');?>vendor/owl-carousel/owl.carousel.js"></script>
<script src="<?php echo base_url('againdashboard/');?>js/custom.min.js"></script>
<script src="<?php echo base_url('againdashboard/');?>js/deznav-init.js"></script>
<script src="<?php echo base_url('againdashboard/');?>js/demo.js"></script>
<script src="<?php echo base_url('againdashboard/');?>js/styleSwitcher.js"></script>
<script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
       <script>$("#tableView").DataTable();</script>

</body>
</html>
