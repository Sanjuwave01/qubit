1<?php include_once'header.php'; ?>
<div class="container">
<div id="content" class="content">
  <h1 class="page-header">
          <span style="">  Payment Response</span>
    </h1>
    <!-- END page-header -->
    <!-- BEGIN wizard -->
    <div id="rootwizard" class="wizard wizard-full-width">

        <div class="wizard-content tab-content">
            <!-- BEGIN tab-pane -->
            <div class="tab-pane active show" id="tabFundRequestForm">
                <!-- BEGIN row -->
                <div class="row">
                    <h1><?php echo $message;?></h2>
                </div>  
                <!-- END row -->
            </div>
        </div>
    </div>
    <!-- END wizard -->
</div>
</div>
<?php include_once'footer.php'; ?>
