<?php include 'header.php'; ?>

<?php include 'footer.php'; ?>
<script>
    $('#kt_chat_modal').modal('open');
</script>