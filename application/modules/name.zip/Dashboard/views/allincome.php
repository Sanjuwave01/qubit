<?php require_once'header.php';?>

 <div class="profile-box">
                            <table class="table table-bordered income-table">
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/wallet.png');?>">
                                                    <h4>E wallet</h4>
                                                    <p>Rs000</p>
                                            </div>
                                        </a>
                                    </td>
                                    <td>
                                         <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/-wallet-1.png');?>">
                                                    <h4>Fund Wallet</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/salary.png');?>">
                                                    <h4>Total income</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                    </td>
                                    <td>
                                         <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/monitor.png');?>">
                                                    <h4>binary income</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/salary.png');?>">
                                                    <h4>Reffer</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/salary.png');?>">
                                                    <h4>GBTT</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/salary.png');?>">
                                                    <h4>Roi Wallet</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/money-bag.png');?>">
                                                    <h4>Roi income</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team.png');?>">
                                                    <h4>Direct income</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/salary.png');?>">
                                                    <h4>manager community</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team.png');?>">
                                                    <h4>Reward</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/data-collection.png');?>">
                                                    <h4>current package</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team.png');?>">
                                                    <h4>Total team</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                    </td>
                                   
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team-1.png');?>">
                                                    <h4>left team</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team-1.png');?>">
                                                    <h4>right team</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team-1.png');?>">
                                                    <h4>left direct</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team-1.png');?>">
                                                    <h4>right direct</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team-1.png');?>">
                                                    <h4>left Sh</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team-1.png');?>">
                                                    <h4>right Sh</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team-1.png');?>">
                                                    <h4>left business</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/team-1.png');?>">
                                                    <h4>right business</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/business.png');?>">
                                                    <h4>Total business</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                    <td>
                                        <a href="#">
                                            <div class="income-box text-center">
                                                <img src="<?php echo base_url('uploads/business.png');?>">
                                                    <h4>loss from capping</h4>
                                                    <p></p>
                                            </div>
                                        </a>
                                        
                                    </td>
                                </tr>
                            </table>
                               
                           </div>

<?php require_once'footer.php';?>