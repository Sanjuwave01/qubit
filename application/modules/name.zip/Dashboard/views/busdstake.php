<?php
include_once 'header.php';
$userinfo = userinfo();
$bankinfo = bankinfo();
?>
<h1>helllo</h1>



<?php include_once 'footer.php'; ?>