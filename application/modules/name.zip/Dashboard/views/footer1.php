
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                               <strong> Copyright @2022. Ricaverse All rights reserved</span.
                            </div>
                        </div>
                    </div>
                </footer>

            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

        <!-- Right Sidebar -->

        <!-- /Right-bar -->

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- JAVASCRIPT -->
        <script src="<?php echo base_url('NewDashboard/') ?>assets/libs/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url('NewDashboard/') ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url('NewDashboard/') ?>assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo base_url('NewDashboard/') ?>assets/libs/simplebar/simplebar.min.js"></script>
        <script src="<?php echo base_url('NewDashboard/') ?>assets/libs/node-waves/waves.min.js"></script>

        <!-- Peity chart-->
        <script src="<?php echo base_url('NewDashboard/') ?>assets/libs/peity/jquery.peity.min.js"></script>

        <!-- Plugin Js-->
        <!-- <script src="<?php //echo base_url('NewDashboard/') ?>assets/libs/chartist/chartist.min.js"></script>
        <script src="<?php //echo base_url('NewDashboard/') ?>assets/libs/chartist-plugin-tooltips/chartist-plugin-tooltip.min.js"></script> -->

        <script src="<?php echo base_url('NewDashboard/') ?>assets/js/pages/dashboard.init.js"></script>

        <script src="<?php echo base_url('NewDashboard/') ?>assets/js/app.js"></script>
        <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
        <script>$("#tableView").DataTable();</script>
    </body>
</html>
