<!DOCTYPE html>
<html lang="en" data-textdirection="ltr">

<head>
  <meta charset="utf-8" />
  <title><?php echo title; ?></title>
  <!-- <meta name="viewport" content="width=device-width, initial-scale=1.0"> -->
  <meta content="<?php echo title; ?>" name="description" />
  <meta content="" name="author" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- App favicon -->
  <link rel="shortcut icon" href="<?php echo base_url('assets/images/logo.png') ?>">
  <meta name="description" content="Ricaverse:  GET EARLY ACCESS TO IDEAS OF TOMORROW  created for crypto currency investment website." />
  <meta name="keywords" content="Ricaverse:  GET EARLY ACCESS TO IDEAS OF TOMORROW  created for crypto currency investment website" />

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <link rel="apple-touch-icon" href="images/ico/apple-icon-120.png" />
  <link rel="shortcut icon" type="image/x-icon" href="images/ico/favicon.ico" />
  <!--Google Fonts-->
  <link href="https://fonts.googleapis.com/css?family=Comfortaa:300,400,500,700" rel="stylesheet" />
  <link rel="stylesheet" href="<?php echo base_url('DashboardOur/') ?>assets/fonts/Facon.ttf" />
  <!--Font icons-->

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css"> <!-- BEGIN VENDOR CSS-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('DashboardOur/') ?>assets/css/themify-style.min.css" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('DashboardOur/') ?>assets/css/flag-icon.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.6.2/animate.min.css" integrity="sha512-HamjnVxTT+zKHJE1w1T2EDHSVvUlFwKgj71I65H73uirwaaAc7gJqfh2jXvGdzTgXvggQzWx5rjRIX6Uf3YCBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="<?php echo base_url('DashboardOur/') ?>assets/css/flipclock.min.css" integrity="sha512-mVGq8839CGwEny4qxCTdXWnfLhviAYLE5IG5d0swMNqwoWuC8jetxQoivyLEsS2MzmH0Yyuh5TzvRGRAPmPeNg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.2.2/css/swiper.min.css" integrity="sha512-dPVdKDXZvfK3D65R2xqeeT1RQtxXFbdvTrSE/E6xaLRuK2yR22DACk/AGIIajRi1BDgsxDm6U1dd/E1gDaxBcg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <!-- END VENDOR CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('DashboardOur/') ?>assets/css/demo.min.css" />
  <!-- END CRYPTO CSS-->
  <!-- BEGIN Page Level CSS-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('DashboardOur/') ?>assets/css/template-counter.min.css" />
  <!-- END Page Level CSS-->
  <!-- BEGIN Custom CSS-->
  <link rel="stylesheet" type="text/css" href="css/style.css" />
  <link rel="stylesheet" href="<?php echo base_url('DashboardOur/') ?>assets/css/custom.css">
  <!-- END Custom CSS-->
<link href="<?php echo base_url() ?>assets/css/normalize.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url() ?>assets/css/components.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url() ?>assets/css/Ricaverse123-8a0df4f42f70223cf3debd856.css" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
  <script type="text/javascript">WebFont.load({  google: {    families: ["Chakra Petch:300,regular,500,600,700"]  }});</script>
  <!-- [if lt IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/html5shiv/3.7.3/html5shiv.min.js" type="text/javascript"></script><![endif] -->
  <script type="text/javascript">!function(o,c){var n=c.documentElement,t=" w-mod-";n.className+=t+"js",("ontouchstart"in o||o.DocumentTouch&&c instanceof DocumentTouch)&&(n.className+=t+"touch")}(window,document);</script>
  <link href="<?php echo base_url() ?>assets/images/favicon.png" rel="shortcut icon" type="image/x-icon">
  <!-- <link
  
      rel="shortcut icon"
      type="image/x-icon"
      href="<?php echo base_url('DashboardOur/') ?>assets/images/ico/favicon.ico"
    /> -->
  <link href="<?php echo base_url() ?>assets/images/webclip.png" rel="apple-touch-icon">
  <style>
    .icon-set {
      color: #fff;
      margin: 5px;
      background: #2826261f;
      padding: 10px;
      border-radius: 10px;
    }

    @media only screen and (max-width: 360px) {
      .nm-tm-wr {
        margin: 0 15px;

      }

    }
  </style>
</head>

<body>
  <!-- Preloader | Comment below code if you don't want preloader-->
  <div id="loader-wrapper">
    <svg viewbox=" 0 0 512 512" id="loader">
      <linearGradient id="loaderLinearColors" x1="0" y1="0" x2="1" y2="1">
        <stop offset="5%" stop-color="#28bcfd"></stop>
        <stop offset="100%" stop-color="#1d78ff"></stop>
      </linearGradient>
      <g>
        <circle cx="256" cy="256" r="150" fill="none" stroke="url(#loaderLinearColors)" />
      </g>
      <g>
        <circle cx="256" cy="256" r="125" fill="none" stroke="url(#loaderLinearColors)" />
      </g>
      <g>
        <circle cx="256" cy="256" r="100" fill="none" stroke="url(#loaderLinearColors)" />
      </g>
      <g>
        <circle cx="256" cy="256" r="75" fill="none" stroke="url(#loaderLinearColors)" />
      </g>
      <circle cx="256" cy="256" r="60" fill="url(#loaderImage)" stroke="none" stroke-width="0" />

      <!-- Change the preloader logo here -->
      <defs>
        <pattern id="loaderImage" height="100%" width="100%" patternContentUnits="objectBoundingBox">
          <image href="<?php echo base_url('DashboardOur/') ?>assets/images/logo.png" preserveAspectRatio="none" width="1" height="1"></image>
        </pattern>
      </defs>
    </svg>

    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
  </div>
  <!--/ Preloader -->

  <!-- MAGIC CURSOR -->
  <div class="mouse-cursor cursor-outer"></div>
  <div class="mouse-cursor cursor-inner"></div>
  <!-- /MAGIC CURSOR -->

 <div class="header-strategy-2 wf-section">
		<div data-collapse="medium" data-animation="default" data-duration="400" data-easing="ease" data-easing2="ease" role="banner" class="navbar-2 w-nav">
			<div class="navbar-container">
			  <div class="navbar-container-left">
				<a href="<?php echo base_url('/') ?>" aria-current="page" class="navbar-brand company w-nav-brand w--current"><img src="<?php echo base_url() ?>assets/images/logo.png" loading="lazy" width="34" alt=""></a>
				<a href="<?php echo base_url('/') ?>" aria-current="page" class="navbar-brand game w-nav-brand w--current">Ricaverse</a>
				<nav role="navigation" class="nav-menu-2 w-nav-menu">
				  <div>
					<a href="#about" class="nav-link-2 w-nav-link">Ricaverse</a>
					<a href="#solutions" class="nav-link-2 w-nav-link">Solutions</a>
					<a href="#ecosystem" class="nav-link-2 w-nav-link">Roadmap</a>
					<a href="#units" class="nav-link-2 w-nav-link">Tokenomics</a>
					<a href="#community2" class="nav-link-2 w-nav-link">COMMUNITY</a>
					<a href="<?php echo base_url();?>Dashboard/blog" class="nav-link-2 w-nav-link">Blog</a>
				  </div>
				  <div class="navbar-container-right">
					
					<div class="nav-action fs-0">
					  <a href="<?php echo base_url();?>Dashboard/Register" class="custom-button-2 small white w-inline-block">
						<div class="custom-button-hover primary"></div>
						<div class="corner-black-2 bottom-right small"></div>
						<div class="corner-black-2 top-left small"></div>
						<div class="custom-button-text">Register</div>
					  </a>
					</div>
					<div class="nav-action fs-0">
					  <a href="<?php echo base_url();?>Dashboard/User/MainLogin" target="_blank" class="custom-button-2 small white custom-button w-inline-block">
						<div class="custom-button-hover primary"></div>
						<div class="corner-black-2 bottom-right small"></div>
						<div class="corner-black-2 top-left small"></div>
						<div class="custom-button-text-blue">login</div>
					  </a>
					</div>
				  </div>
				</nav>
				<div class="menu-button-container">
				  <div class="menu-button-2 w-nav-button"><img src="<?php echo base_url() ?>assets/images/icons8-squared-menu-100_1icons8-squared-menu-100.png" loading="lazy" width="20" alt="" class="menu-button-icon"></div>
				</div>
			  </div>
			</div>
		</div>
       </div>
  <main id="page-content" class="d-flex nm-aic nm-vh-md-100" style="position: relative;">
    
    <span class="text-danger"><?php echo $this->session->flashdata('error'); ?></span>


    <div class="nm-tm-wr">
      <div class="container">
        <p style="color:red;text-align: center;"><?php echo $message; ?></p>
        <?php echo form_open(base_url('Dashboard/User/MainLogin'), array('id' => 'loginForm')); ?>
        <form id="loginForm" method="post" action="/login.asp?ReturnURL=">
          <div class="nm-hr nm-up-rl-3">
            <h2>Login</h2>
            <ul class="social-buttons">
              <li class="nm-hvr">
                <a href="http://google.com/">
                  <i class="fab fa-google icon-set"></i>
                </a>
              </li>
              <li class="nm-hvr">
                <a href="https://twitter.com/VerseRica">
                  <i class="fab fa-twitter icon-set"></i>
                </a>
              </li>
              <li class="nm-hvr">
                <a href="https://www.facebook.com/profile.php?id=100090027950943">
                  <i class="fab fa-facebook-f icon-set"></i>
                </a>
              </li>
            </ul>
          </div>


          <div class="input-group nm-gp">
            <span class="nm-gp-pp"><i class="fas fa-user"></i></span>
            <?php
            echo form_input(array(
              'type' => 'text',
              'name' => 'user_id',
              'class' => 'form-control',
              'placeholder' => 'User ID',
              'required' => 'true',
            ));
            ?>
          </div>

          <div class="input-group nm-gp">
            <span class="nm-gp-pp"><i id="togglePassword" class="fas fa-lock"></i></span>
            <?php
            echo form_input(array(
              'type' => 'password',
              'name' => 'password',
              'id' => 'password_id',
              'class' => 'form-control',
              'placeholder' => 'Enter Password',
              'required' => 'true',
            ));
            ?>
		
 <i id="eye" class="fas fa-eye-slash" style="padding-top:14px;"></i>
     </div>
          <div class="input-group nm-gp">
            <div class="form-check">
              <input type="checkbox" class="form-check-input" id="rememberMe">
              <label class="form-check-label nm-check" for="rememberMe">Keep me logged in</label>
            </div>
          </div>

          <div class="row nm-aic nm-mb-1">
            <div class="col-sm-6 nm-mb-1 nm-mb-sm-0">
              <button type="submit" class="btn btn-lg btn-gradient-orange btn-round btn-glow">Log In</button>
            </div>

            <div class="col-sm-6 nm-sm-tr">
              <a class="nm-fs-1 nm-fw-bd" href="<?php echo base_url('Dashboard/User/forgot_password'); ?>">Forgot Password?</a>
            </div>
          </div>

          <footer style="text-align: center; margin-top: 2rem; font-size: 0.75rem; color: #97a4af; font-weight: 400;">Don't have an account? <a class="nm-fs-1 nm-fw-bd" style="font-size: 0.75rem;" href="<?php echo base_url('Dashboard/Register'); ?>">Signup</a></footer>
        </form>
      </div>
    </div>
  </main>
  <!-- BEGIN VENDOR JS-->
  <script src="<?php echo base_url('DashboardOur/') ?>assets/js/vendor.min.js"></script>
  <script src="<?php echo base_url('DashboardOur/') ?>assets/js/mouse.js"></script>
  <!-- BEGIN VENDOR JS-->

  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init();
  </script>
  <!-- END PAGE VENDOR JS-->
  <!-- BEGIN THEME JS-->
  <script src="<?php echo base_url('DashboardOur/') ?>assets/js/theme.min.js"></script>
  <!-- JAVASCRIPT -->
  <script src="<?php echo base_url('NewDashboard/') ?>assets/libs/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url('NewDashboard/') ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo base_url('NewDashboard/') ?>assets/libs/metismenu/metisMenu.min.js"></script>
  <script src="<?php echo base_url('NewDashboard/') ?>assets/libs/simplebar/simplebar.min.js"></script>


  <script src="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.js"></script>
  <link rel="stylesheet" href="//cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" id="theme-styles">
  <!-- <script src="<?php echo base_url('SmartChain/web3.min.js'); ?>"></script>
<script src="<?php echo base_url('SmartChain/web3modal.js'); ?>"></script>
<script src="<?php echo base_url('SmartChain/evm-chains.js'); ?>"></script>

<script src="<?php echo base_url('SmartChain/config.js'); ?>"></script>
<script src="<?php echo base_url('SmartChain/index.js'); ?>"></script> -->
  <!-- <script src="<?php echo base_url('NewDashboard/') ?>assets/js/app.js"></script>
<script src="<?php echo base_url('NewDashboard/'); ?>assets/js/particles-type1.min.js"></script>
<script src="<?php echo base_url('NewDashboard/'); ?>assets/js/particles.min.js"></script> -->
<script>
$(function(){
  
  $('#eye').click(function(){
       
        if($(this).hasClass('fa-eye-slash')){
           
          $(this).removeClass('fa-eye-slash');
          
          $(this).addClass('fa-eye');
          
          $('#password_id').attr('type','text');
            
        }else{
         
          $(this).removeClass('fa-eye');
          
          $(this).addClass('fa-eye-slash');  
          
          $('#password_id').attr('type','password');
        }
    });
});
</script>
  <script>
    particlesJS("particles-js", {
      "particles": {
        "number": {
          "value": 80,
          "density": {
            "enable": true,
            "value_area": 800
          }
        },
        "color": {
          "value": "#ffffff"
        },
        "shape": {
          "type": "circle",
          "stroke": {
            "width": 0,
            "color": "#000000"
          },
          "polygon": {
            "nb_sides": 5
          }
        },
        "opacity": {
          "value": 0.5,
          "random": false,
          "anim": {
            "enable": false,
            "speed": 1,
            "opacity_min": 0.1,
            "sync": false
          }
        },
        "size": {
          "value": 3,
          "random": true,
          "anim": {
            "enable": false,
            "speed": 40,
            "size_min": 0.1,
            "sync": false
          }
        },
        "line_linked": {
          "enable": true,
          "distance": 150,
          "color": "#ffffff",
          "opacity": 0.4,
          "width": 1
        },
        "move": {
          "enable": true,
          "speed": 6,
          "direction": "none",
          "random": true,
          "straight": false,
          "out_mode": "out",
          "bounce": false,
          "attract": {
            "enable": false,
            "rotateX": 600,
            "rotateY": 1200
          }
        }
      },
      "interactivity": {
        "detect_on": "canvas",
        "events": {
          "onhover": {
            "enable": true,
            "mode": "grab"
          },
          "onclick": {
            "enable": true,
            "mode": "push"
          },
          "resize": true
        },
        "modes": {
          "grab": {
            "distance": 140,
            "line_linked": {
              "opacity": 1
            }
          },
          "bubble": {
            "distance": 400,
            "size": 40,
            "duration": 2,
            "opacity": 8,
            "speed": 3
          },
          "repulse": {
            "distance": 200,
            "duration": 0.4
          },
          "push": {
            "particles_nb": 4
          },
          "remove": {
            "particles_nb": 2
          }
        }
      },
      "retina_detect": true



    });
  </script>

</body>

</html>
<script>
  const togglePassword = document
    .querySelector('#togglePassword');
  const password = document.querySelector('#password_id');
  togglePassword.addEventListener('click', () => {
    const type = password
      .getAttribute('type') === 'password' ?
      'text' : 'password';
    password.setAttribute('type', type);
    this.classList.toggle('bi-eye');
  });
</script>