  <footer class="footer">
            <div class="container">
              <div class="d-sm-flex justify-content-center text-center">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2021 <a href="#" target="_blank"><?php echo title;?></a>. All rights reserved.</span>
               
              </div>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
<!--     <script src="<?php //echo base_url('');?>NewDashboard/assets/libs/jquery/jquery.min.js"></script> -->
    <script src="<?php echo base_url('');?>assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="<?php echo base_url('');?>assets/vendors/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url('');?>assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo base_url('');?>assets/js/off-canvas.js"></script>
    <script src="<?php echo base_url('');?>assets/js/hoverable-collapse.js"></script>
    <script src="<?php echo base_url('');?>assets/js/misc.js"></script>
    <script src="<?php echo base_url('');?>assets/js/settings.js"></script>
    <script src="<?php echo base_url('');?>assets/js/todolist.js"></script>
    <script src="<?php echo base_url('');?>assets/js/jquery.cookie.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="<?php echo base_url('');?>assets/js/dashboard.js"></script>
    <!-- End custom js for this page -->
        <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
        <script>$("#tableView").DataTable();</script>
  </body>
</html>