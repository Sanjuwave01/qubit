<?php include'header.php' ?>
<div id="content" class="content container-fluid ">
    <h2 class="page-titel">
        <span style="font-size:20px">Amazon Shopping</span>
    </h2>
    <div class="row">
        <div class="col-md-3">
            <script type="text/javascript" language="javascript">
            var aax_size = '160x600';
            var aax_pubname = 'happybusine06-21';
            var aax_src = '302';
            </script>
            <script type="text/javascript" language="javascript" src="https://c.amazon-adsystem.com/aax2/assoc.js">
            </script>
        </div>
        <div class="col-md-9">
            <script type="text/javascript">
            amzn_assoc_ad_type = "responsive_search_widget";
            amzn_assoc_tracking_id = "happybusine06-21";
            amzn_assoc_marketplace = "amazon";
            amzn_assoc_region = "IN";
            amzn_assoc_placement = "";
            amzn_assoc_search_type = "search_widget";
            amzn_assoc_width = "900";
            amzn_assoc_height = "900";
            amzn_assoc_default_search_category = "";
            amzn_assoc_default_search_key = "";
            amzn_assoc_theme = "light";
            amzn_assoc_bg_color = "FFFFFF";
            </script>
            <script
                src="//z-in.amazon-adsystem.com/widgets/q?ServiceVersion=20070822&Operation=GetScript&ID=OneJS&WS=1&Marketplace=IN">
            </script>
        </div>
    </div>
</div>
<?php include'footer1.php' ?>